This `deprecated` directory holds examples of deprecated code reference in the docs,
all of them for an app built with NgModules.