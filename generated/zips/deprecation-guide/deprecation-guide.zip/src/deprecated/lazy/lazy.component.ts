import { Component } from '@angular/core';

@Component({
  selector: 'app-lazy',
  template: `<p>lazy works!</p>`
})
export class LazyComponent {}
