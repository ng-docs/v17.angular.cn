/*
 * This example project is special in that it is not a cli app. To run tests appropriate for this
 * project, the test command is overwritten in `aio/content/examples/rx-libary/example-config.json`.
 *
 * This is an empty placeholder file to ensure that `aio/tools/examples/run-example-e2e.mjs` runs
 * tests for this project.
 *
 * TODO: Fix our infrastructure/tooling, so that this hack is not necessary.
 */
