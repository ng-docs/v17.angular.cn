export interface Schema {
  // Name of the project.
  project: string;
}
