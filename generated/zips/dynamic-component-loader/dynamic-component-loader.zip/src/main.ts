import { bootstrapApplication } from '@angular/platform-browser';
import { AdBannerComponent } from './app/ad-banner.component';

bootstrapApplication(AdBannerComponent);
