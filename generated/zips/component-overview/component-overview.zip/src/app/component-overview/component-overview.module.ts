import {NgModule} from '@angular/core';
// Your component path
import {ComponentOverviewComponent} from './component-overview.component';

@NgModule({
  declarations: [
    // Existing Components
   ComponentOverviewComponent
  ]
  // Rest of the Module Content
})
export class ComponentOverviewModule {}
